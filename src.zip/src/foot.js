const Foot=()=>{
    return (
        <>
        <h1>
            Footer
        </h1>
        </>
    )
}
export default Foot;