// import React, { useState } from 'react';

// function CreateResume() {
//   const [formData, setFormData] = useState({
//     firstName: '',
//     lastName: '',
//     email: '',
//     phone: '',
//     address: '',
//     city: '',
//     state: '',
//     zip: '',
//     education: '',
//     experience: '',
//     project1: '',
//     project2: '',
//     certification1: '',
//     certification2: '',
//     skill1: '',
//     skill2: '',
//     skill3: '',
//     photo: ''
//   });

//   const handleChange = (event) => {
//     const { name, value } = event.target;
//     setFormData({ ...formData, [name]: value });
//   };

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     console.log(formData);
//   };

//   return (
// <>
// <br/><br/>
// <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
//       <label htmlFor="firstName" style={{ marginBottom: '0.5rem',textALign:'left' }}>First Name:</label>
//       <input type="text" id="firstName" name="firstName" value={formData.firstName} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="lastName" style={{ marginBottom: '0.5rem' }}>Last Name:</label>
//       <input type="text" id="lastName" name="lastName" value={formData.lastName} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="email" style={{ marginBottom: '0.5rem' }}>Email:</label>
//       <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="phone" style={{ marginBottom: '0.5rem' }}>Phone:</label>
//       <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="address" style={{ marginBottom: '0.5rem' }}>Address:</label>
//       <input type="text" id="address" name="address" value={formData.address} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="city" style={{ marginBottom: '0.5rem' }}>City:</label>
//       <input type="text" id="city" name="city" value={formData.city} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="state" style={{ marginBottom: '0.5rem' }}>State:</label>
//       <input type="text" id="state" name="state" value={formData.state} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="zip" style={{ marginBottom: '0.5rem' }}>Zip:</label>

//       <input type="text" id="zip" name="zip" value={formData.zip} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom:  '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="education" style={{ marginBottom: '0.5rem' }}>Education:</label>
//       <input type="text" id="education" name="education" value={formData.education} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="experience" style={{ marginBottom: '0.5rem' }}>Experience:</label>
//       <input type="text" id="experience" name="experience" value={formData.experience} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="project1" style={{ marginBottom: '0.5rem' }}>Project 1:</label>
//       <input type="text" id="project1" name="project1" value={formData.project1} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="project2" style={{ marginBottom: '0.5rem' }}>Project 2:</label>
//       <input type="text" id="project2" name="project2" value={formData.project2} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="certification1" style={{ marginBottom: '0.5rem' }}>Certification 1:</label>
//       <input type="text" id="certification1" name="certification1" value={formData.certification1} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="certification2" style={{ marginBottom: '0.5rem' }}>Certification 2:</label>
//       <input type="text" id="certification2" name="certification2" value={formData.certification2} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="skill1" style={{ marginBottom: '0.5rem' }}>Skill 1:</label>
//       <input type="text" id="skill1" name="skill1" value={formData.skill1} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="skill2" style={{ marginBottom: '0.5rem' }}>Skill 2:</label>
//       <input type="text" id="skill2" name="skill2" value={formData.skill2} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="skill3" style={{ marginBottom: '0.5rem' }}>Skill 3:</label>
//       <input type="text" id="skill3" name="skill3" value={formData.skill3} onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '0.25rem' }} />

//       <label htmlFor="photo" style={{ marginBottom: '0.5rem' }}>Photo:</label>
//       <input type="file" id="photo" name="photo" accept="image/*" onChange={handleChange} style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem' }} />

//       <button type="submit" style={{ padding: '0.5rem 1rem', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '0.25rem', cursor: 'pointer' }}>Submit</button>
//     </form>
// </>
//   );
// }

// export default CreateResume;
import React, { useState } from "react";

const CreateResume = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    certification1: "",
    certification2: "",
    skill1: "",
    skill2: "",
    skill3: "",
    photo: "",
    education: "",
    experience: "",
    project1: "",
    project2: "",
  });

  const handleChange = (event) => {
    setFormData({
      ...formData,
      [event.target.name]: event.target.value,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(formData);
    // code to submit the form data to a backend API or database
  };

  const labelStyle = {
    display: "block",
    marginBottom: "5px",
    fontWeight: "bold",
  };

  const inputStyle = {
    padding: "10px",
    border: "none",
    borderRadius: "5px",
    marginBottom: "15px",
    width: "100%",
  };

  const textAreaStyle = {
    padding: "10px",
    border: "none",
    borderRadius: "5px",
    marginBottom: "15px",
    width: "100%",
    height: "100px",
  };

  const formStyle = {
    width: "80%",
    margin: "0 auto",
  };

  const formContainer = {
    backgroundColor: "#f2f2f2",
    padding: "50px",
  };

  const nameContainer = {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "15px",
  };

  const inputContainer = {
    width: "48%",
  };

  return (
    <div style={formContainer}>
      <form onSubmit={handleSubmit} style={formStyle}>
        <h2 style={{ textAlign: "center", marginBottom: "25px" }}>
          Create Your Resume
        </h2>
        <div style={nameContainer}>
          <div style={inputContainer}>
            <label style={labelStyle}>First Name:</label>
            <input
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              style={inputStyle}
            />
          </div>
          <div style={inputContainer}>
            <label style={labelStyle}>Last Name:</label>
            <input
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              style={inputStyle}
            />
          </div>
        </div>
        <div style={{ marginBottom: "15px" }}>
          <label style={labelStyle}>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            style={inputStyle}
          />
        </div>
        <div style={{ marginBottom: "15px" }}>
          <label style={labelStyle}>Phone:</label>
          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            style={inputStyle}
          />
        </div>
        <div style={{ marginBottom: "15px" }}>
          <label style={labelStyle}>Address:</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            style={inputStyle}
          />
        </div>
        <div style={nameContainer}>
          <div      style={{ ...inputContainer, marginRight: "4%" }}
    >
      <label style={labelStyle}>City:</label>
      <input
        type="text"
        name="city"
        value={formData.city}
        onChange={handleChange}
        style={inputStyle}
      />
    </div>
    <div style={inputContainer}>
      <label style={labelStyle}>State:</label>
      <input
        type="text"
        name="state"
        value={formData.state}
        onChange={handleChange}
        style={inputStyle}
      />
    </div>
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Zip Code:</label>
    <input
      type="text"
      name="zip"
      value={formData.zip}
      onChange={handleChange}
      style={inputStyle}
    />
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Certification 1:</label>
    <input
      type="text"
      name="certification1"
      value={formData.certification1}
      onChange={handleChange}
      style={inputStyle}
    />
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Certification 2:</label>
    <input
      type="text"
      name="certification2"
      value={formData.certification2}
      onChange={handleChange}
      style={inputStyle}
    />
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Skill 1:</label>
    <input
      type="text"
      name="skill1"
      value={formData.skill1}
      onChange={handleChange}
      style={inputStyle}
    />
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Skill 2:</label>
    <input
      type="text"
      name="skill2"
      value={formData.skill2}
      onChange={handleChange}
      style={inputStyle}
    />
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Skill 3:</label>
    <input
      type="text"
      name="skill3"
      value={formData.skill3}
      onChange={handleChange}
      style={inputStyle}
    />
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Education:</label>
    <textarea
      name="education"
      value={formData.education}
      onChange={handleChange}
      style={textAreaStyle}
    ></textarea>
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Experience:</label>
    <textarea
      name="experience"
      value={formData.experience}
      onChange={handleChange}
      style={textAreaStyle}
    ></textarea>
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Project 1:</label>
    <textarea
      name="project1"
      value={formData.project1}
      onChange={handleChange}
      style={textAreaStyle}
    ></textarea>
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Project 2:</label>
    <textarea
      name="project2"
      value={formData.project2}
      onChange={handleChange}
      style={textAreaStyle}
    ></textarea>
  </div>
  <div style={{ marginBottom: "15px" }}>
    <label style={labelStyle}>Photo:</label>
    <input
      type="file"
      name="photo"
      onChange={handleChange}
      style={{ marginBottom: "15px" }}
    />
  </div>
  <button type="submit" className="btn btn-success" style={{ padding: "10px 20px" }}>
    Submit
  </button>
</form>
</div>
  );
};
export default CreateResume;






